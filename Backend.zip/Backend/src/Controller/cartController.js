const mongoose = require("mongoose");
const cartModel=require("../Model/cartModel.js")
const {isValid}=require("./validator");
const productModel = require("../Model/productModel");
// const productModel=require("../Model/productModel.js")

const addToCart=async(req,res)=>{
    try {
       let userId=req.user.userId;

        //userId Validation
       if(!isValid(userId)|| !mongoose.Types.ObjectId.isValid(userId)){
        return res.status(400).json({message:"valid User Id is required"})
       }

       let {productId,quantity}=req.body;

       //productId Validation
       if(!isValid(productId)|| !mongoose.Types.ObjectId.isValid(productId)){
        return res.status(400).json({message:"valid Product Id is required"})
       }

       //quantity Validation
       if(
        !isValid(quantity)||
        typeof quantity!=="number" || 
        !Number.isInteger(quantity) || quantity>1){
        return res.status(400).json({message:"valid quantity is required" })
       }

       let product=await productModel.findById(productId);
       if(!product){
        return res.status(404).json({message:"product not found"})
       }

       let cart=await cartModel.findOne({userId});
       if(!cart){
        cart=await cartModel.create({
            userId,
            items:[{productId,quantity}],
            totalItems:1,
            totalPrice:product.price*quantity
        })
       }
       else{

       }
        
    } catch (error) {
        console.log(error);
        return res.status(500).json({msg:"Internal server error",error});
        
    }
};
module.exports={addToCart};
