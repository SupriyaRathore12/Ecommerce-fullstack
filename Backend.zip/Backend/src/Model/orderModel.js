const mongoose=require("mongoose")

const orderSchema=new mongoose({
  
    userId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"user",
        required:true,
        unique:true,
    },
     items:[
            {
                productId:{
                    type:mongoose.Schema.Types.ObjectId,
                    ref:"product",
                    required:true,
                },
                quantity:{
                    type:Number,
                    required:true,
                    min:1,
                }
            }
        ],
        totalItems:{
            type:Number,
            required:true,
           
        },
        totalPrice:{
            type:Number,
            required:true,
            
        },

    cartId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"cart",
        required:true,
        unique:true,

    },

    orderStatus:{
        type:String,
        required:true,
        enum:["pending","shipped","deliverd","cancelled"],
        trim:true,

    },
    paymentMode:{
        type:String,
        required:true,
        enum:["cash" ,"onlineMode"],
        default:"default",
        trim:true,
    },
    paymentStatus:{
        type:String,
        enum:["pending","successful","failed"],
        trim:true,
        default:"pending",
        
    },
    shippingAddress:{
        type:String,
        required:true,
        trim:true,
    
}
},

{timeStamps:true},
);
module.exports= new mongoose.model("order",orderSchema);